const express = require('express');
const cors = require('cors')
const app = express();
const port = 3000;
const key = "Bearer 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"




app.use(express.json())
app.use(cors())

app.get('/', function(req, res){
    res.send("Bem Vindo");
})

app.post('/chat', function(req, res){
    const input = req.body.input;
    let ultimaMensagem = "";
    
    async function apiChat(prompt){

        const resposta = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                authorization: key,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    { "role": "system", "content": "Você é um assistente útil, no qual deve se chamar Walter" },
                    { "role": "user", "content": "Para você se lembarar do assunto que estavmos conversando, essa foi a sua ultima mensagem para mim "+ultimaMensagem+" caso ela esteja vazia, ignore isso. Ademais, agora que você já sabe do que estavamos conversando, me faça isso: "+prompt }
                ]
            })
        })

        const dados = await resposta.json()

        ultimaMensagem = dados.choices[0].message.content

        res.json({
            mensagem: dados.choices[0].message.content
        })

        

    }

    apiChat(input)



})

app.listen(port, function(){
    console.log(`Servidor rodando na url http://localhost:${port}`);
})